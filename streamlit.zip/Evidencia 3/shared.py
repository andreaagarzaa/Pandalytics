import pandas as pd
import streamlit as st


@st.cache_data
def get_paint_per_date():
    return pd.read_feather('data/paint_per_date.feather').reset_index()


def convert_period_opt(value: str):
    if value == 'yearmonth':
        return 'Mensual'
    elif value == 'yearweek':
        return 'Semanal'
    elif value == 'yearmonthdate':
        return 'Diario'


@st.cache_data
def is_in_both_production_lines(paint: str) -> bool:
    df = get_paint_per_date()
    freq = df[df['paint_name'] == paint]['production_line'].value_counts()
    return all(freq > 0)


@st.cache_data
def remove_single_production_line_paints(df: pd.DataFrame) -> pd.DataFrame:
    groups = df.groupby('paint_name')

    in_both_pls_dfs = []
    for name, group in groups:
        freq = group['production_line'].value_counts()
        if all(freq > 0):
            in_both_pls_dfs.append(group)
    return pd.concat(in_both_pls_dfs)


@st.cache_data
def get_paint_names_by_usage(df: pd.DataFrame, ascending=False) -> pd.DataFrame:
    return list(df[['paint_name', 'real_yield']].groupby('paint_name').count().sort_values(by='real_yield',
                                                                                           ascending=ascending).index)


@st.cache_data
def get_production_lines(df):
    groups = df.groupby(['production_line'])
    p1_df = groups.get_group('Pintado 1')
    p2_df = groups.get_group('Pintado 2')
    return p1_df, p2_df
