
def add_sidebar(st) -> None:
    with st.sidebar:
        st.image('logo.png', width=30)
        st.page_link('index.py', label='Inicio', icon=':material/home:')
        st.page_link('pages/dashboard.py', label='Dashboard', icon=':material/dashboard:')
        st.page_link('pages/problem.py', label='Hallazgos', icon=':material/query_stats:')
        st.page_link('pages/machine_learning.py', label='Proyecciones', icon=':material/neurology:')
        st.page_link('pages/recommendations.py', label='Recomendaciones', icon=':material/assignment:')
