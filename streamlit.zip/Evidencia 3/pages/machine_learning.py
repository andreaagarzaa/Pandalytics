from datetime import datetime, timedelta
import numpy as np
import streamlit as st
from layout.sidebar import add_sidebar
import pandas as pd
import altair as alt
from prophet import Prophet
from shared import remove_single_production_line_paints, get_production_lines, get_paint_per_date

st.set_page_config(layout="wide")

add_sidebar(st)

st.title('Proyecciones')


@st.cache_data
def get_prophet(df: pd.DataFrame, prediction: object, time: datetime):
    date_grouper = pd.Grouper(key='ds', freq='W')
    prophet_df = df[['date', prediction]].rename(columns={
        'date': 'ds',
        prediction: 'y',
    }).groupby(date_grouper).sum().reset_index()

    prophetModel = Prophet()
    prophetModel.fit(prophet_df)
    date = prophet_df['ds'].max()
    weeks = round((pd.to_datetime(time) - date).days / 7)
    future = prophetModel.make_future_dataframe(periods=weeks, freq='W')

    prophet_predictions = prophetModel.predict(future)
    return prophet_predictions[['ds', 'yhat', 'yhat_lower', 'yhat_upper']]


@st.cache_data
def date_group(df: pd.DataFrame):
    date_grouper = pd.Grouper(key='date', freq='W')
    grouped_df = df[['date', 'total_liters_used', 'm2', 'monetary_value_usd']].groupby(date_grouper).sum().reset_index()
    return grouped_df


paint_per_date_df = get_paint_per_date()
paint_per_date_df_both_lines = remove_single_production_line_paints(paint_per_date_df)
p1_df, p2_df = get_production_lines(paint_per_date_df_both_lines)

grouped_p1_df = date_group(p1_df)
grouped_p2_df = date_group(p2_df)

col1, col2 = st.columns(2)
with col1:
    prediction = st.selectbox('Seleccione la variable a predecir',
                              ['total_liters_used', 'm2', 'monetary_value_usd'])

with col2:
    limits = st.date_input('Ingrese la fecha final para la predicción',
                           paint_per_date_df_both_lines['date'].max() + np.timedelta64(24, 'W'),
                           min_value=paint_per_date_df_both_lines['date'].max() + np.timedelta64(24, 'W'),
                           max_value=paint_per_date_df_both_lines['date'].max() + np.timedelta64(104, 'W'))
    # if len(limits) != 2:
    #     st.stop()

prophet_col1, prophet_col2 = st.columns(2)
with prophet_col1:
    prophet_l1 = get_prophet(p1_df, prediction, limits)
    l1_chart = alt.Chart(prophet_l1, title='Línea 1')
    l1_scatter = alt.Chart(grouped_p1_df).mark_point(color='black', size=5).encode(
        x=alt.X('date', timeUnit='yearweek'),
        y=alt.Y(prediction))
    prophet_chart_1_hat = l1_chart.mark_line().encode(
        x=alt.X('ds', timeUnit='yearweek', title='Fecha'),
        y=alt.Y('yhat', title=f'{prediction}'))
    prophet_char_1_limits = l1_chart.mark_errorband(color='#b2d4e7').encode(
        alt.Y('yhat_lower', title=f'{prediction}'),
        alt.Y2('yhat_upper'),
        alt.X('ds', timeUnit='yearweek', title='Fecha'))
    st.altair_chart(
        l1_scatter + prophet_chart_1_hat + prophet_char_1_limits,
        use_container_width=True,
    )

with prophet_col2:
    prophet_l2 = get_prophet(p2_df, prediction, limits)
    l2_chart = alt.Chart(prophet_l2, title='Línea 2')
    l2_scatter = alt.Chart(grouped_p2_df).mark_point(color='black', size=5).encode(
        x=alt.X('date', timeUnit='yearweek'),
        y=alt.Y(prediction))
    prophet_chart_2_hat = l2_chart.mark_line().encode(
        x=alt.X('ds', timeUnit='yearweek', title='Fecha'),
        y=alt.Y('yhat', title=f'{prediction}'))
    prophet_char_2_limits = l2_chart.mark_errorband(color='#b2d4e7').encode(
        alt.Y('yhat_lower', title=f'{prediction}'),
        alt.Y2('yhat_upper'),
        alt.X('ds', timeUnit='yearweek', title='Fecha'))
    st.altair_chart(
        l2_scatter + prophet_chart_2_hat + prophet_char_2_limits,
        use_container_width=True,
    )

# prediction_df = prophet_l1[['ds', 'yhat']].rename(columns={'ds': 'date', 'yhat': 'Línea 1'})
# prediction_df['Línea 2'] = prophet_l2['yhat']
# prediction_df['Línea'] = len(prediction_df['date']) * ['Línea 1']
# prediction_df['de producción'] = len(prediction_df['date']) * ['Línea 2']
#
# prediction_df_l1_chart = alt.Chart(prediction_df, title='Diferencia de Línea 1 con Línea 2').mark_line().encode(
#     x=alt.X('date', timeUnit='yearweek', title='Fecha'),
#     y=alt.Y('Línea 1', title=f'{prediction}'),
#     opacity='Línea')
#
# prediction_df_l2_chart = alt.Chart(prediction_df).mark_line().encode(
#     x=alt.X('date', timeUnit='yearweek', title='Fecha'),
#     y=alt.Y('Línea 2', title=f'{prediction}'),
#     opacity='de producción')
#
# st.altair_chart(
#     prediction_df_l1_chart + prediction_df_l2_chart,
#     use_container_width=True,
#     )

prophet_l1_modified = prophet_l1
prophet_l2_modified = prophet_l2
prophet_l1_modified['Línea'] = len(prophet_l1['ds']) * ['Línea 1']
prophet_l2_modified['Línea'] = len(prophet_l2['ds']) * ['Línea 2']

prediction_df = pd.concat(objs=[prophet_l1_modified, prophet_l2_modified])

prediction_df_chart = alt.Chart(prediction_df, title='Diferencia de Línea 1 con Línea 2').transform_fold(
    ['Línea 1', 'Línea 2']).mark_line().encode(
    x=alt.X('ds', timeUnit='yearweek', title='Fecha'),
    y=alt.Y('yhat', title=f'{prediction}'),
    opacity='Línea')

st.altair_chart(prediction_df_chart, use_container_width=True)
