import streamlit as st
from layout.sidebar import add_sidebar
import altair as alt
import pandas as pd

from shared import get_paint_per_date, convert_period_opt, remove_single_production_line_paints, \
    get_paint_names_by_usage

add_sidebar(st)


@st.cache_data
def get_paint_yields_df(paint_per_date_df):
    paint_groups = paint_per_date_df[['paint_name', 'real_yield']].groupby('paint_name')
    paint_yields = paint_groups.mean().rename(columns={
        'real_yield': 'Rendimiento promedio (L/m²)'
    }).join(paint_groups.count().rename(columns={
        'real_yield': 'Días de uso'
    })).sort_values(by='Rendimiento promedio (L/m²)', ascending=False)

    paint_yields.index.name = 'Nombre de pintura'
    return paint_yields.reset_index()


@st.cache_data
def get_yield_diff_df(paint_per_date_df):
    production_line_groups = paint_per_date_df.groupby('production_line')

    p1_df = production_line_groups.get_group('Pintado 1')[['real_yield', 'date']].groupby('date').mean().rename(
        columns={'real_yield': 'Pintado 1'})
    p2_df = production_line_groups.get_group('Pintado 2')[['real_yield', 'date']].groupby('date').mean().rename(
        columns={'real_yield': 'Pintado 2'})

    return p1_df.join(p2_df).assign(
        diff=lambda df: df['Pintado 2'] - df['Pintado 1'],
    ).reset_index()


@st.cache_data
def get_yield_diff_df_for_paint(paint_per_date_df: pd.DataFrame, paint_name: str):
    production_line_groups = paint_per_date_df[paint_per_date_df['paint_name'] == paint_name].groupby('production_line')

    p1_df = production_line_groups.get_group('Pintado 1')[['real_yield', 'date']].groupby('date').mean().rename(
        columns={'real_yield': 'Pintado 1'})
    p2_df = production_line_groups.get_group('Pintado 2')[['real_yield', 'date']].groupby('date').mean().rename(
        columns={'real_yield': 'Pintado 2'})

    return p1_df.join(p2_df).assign(
        diff=lambda df: df['Pintado 2'] - df['Pintado 1'],
    ).reset_index().fillna(0)


@st.cache_data
def get_paint_price_per_liter(paint_per_date_df: pd.DataFrame):
    paint_price = paint_per_date_df[['paint_name', 'total_liters_used', 'monetary_value_usd']].groupby(
        'paint_name').mean()
    paint_price['price_per_liter_usd'] = paint_price['monetary_value_usd'] / paint_price['total_liters_used']
    return paint_price.reset_index()


st.title('Hallazgos')

st.markdown('''
Para intentar encontrar una solución al problema del desperdicio de pintura de Ternium, empezamos buscando una medida 
cuantitativa de esta pérdida. La medida elegida para medir esto es el rendimiento de pintura. Este dato nos permite
medir cuantos litros de pintura se gastan por cada metro cuadrado pintado, medido en L/m². Calculamos este dato y lo 
generamos para cada pintura dentro de la base de datos proporcionada por Ternium. A continuación, se muestra un 
rendimiento promedio para cada pintura, así como el número de días en los cuales fue usada cierta pintura. 
''')

paint_per_date_df = get_paint_per_date()

paint_yields = get_paint_yields_df(paint_per_date_df)

yield_diff_df = get_yield_diff_df(paint_per_date_df)

st.dataframe(paint_yields, use_container_width=True, hide_index=True)

st.markdown('''
Después de realizar este cálculo, analizamos la manera en que esta variable interactuaba con otras variables dentro de
la base de datos. Esto nos llevó a descubrir una correlación entre el rendimiento de las pinturas y la línea de producción
en la cual se está usando. El siguiente gráfico muestra la variación del rendimiento de la pintura a través del tiempo, 
separado por línea de producción.
''')

# Filtering
col1, col2 = st.columns(2)

with col1:
    period = st.radio('Tamaño de periodo', options=['yearmonth', 'yearweek', 'yearmonthdate'],
                      format_func=convert_period_opt)

    with col2:
        limits = st.date_input('Rango de tiempo', [paint_per_date_df['date'].min(), paint_per_date_df['date'].max()],
                               paint_per_date_df['date'].min(), paint_per_date_df['date'].max())

if len(limits) > 1:
    paint_per_date_df = paint_per_date_df[pd.to_datetime(limits[1]) > paint_per_date_df['date']]
    yield_diff_df = yield_diff_df[pd.to_datetime(limits[1]) > yield_diff_df['date']]

paint_per_date_df = paint_per_date_df[pd.to_datetime(limits[0]) < paint_per_date_df['date']]
yield_diff_df = yield_diff_df[pd.to_datetime(limits[0]) < yield_diff_df['date']]

yield_chart = alt.Chart(paint_per_date_df,
                        title='Rendimiento promedio por línea de producción por mes').mark_line(point=True).encode(
    x=alt.X('date', timeUnit=period, title='Fecha'),
    y=alt.Y('real_yield', aggregate='mean', title='Rendimiento (L/m²)'),
    color=alt.Color('production_line', title='Línea de producción'))

st.altair_chart(
    yield_chart,
    use_container_width=True,
)

st.markdown('''
Viendo este gráfico, hay un patrón claro: la línea de pintado 1 presenta consistentemente menores rendimientos que la 
línea de pintado 2. Si directamente gráficamos la diferencia entre estas dos líneas de producción, el patrón se es mucho
más evidente:
''')

diff_chart = alt.Chart(yield_diff_df,
                       title='Diferencia entre las líneas de producción (línea 2 menos línea 1)').mark_line(
    point=True).encode(
    x=alt.X('date', timeUnit=period, title='Fecha'),
    y=alt.Y('diff', aggregate='mean', title='Diferencia (L/m²)'),
)

st.altair_chart(
    diff_chart,
    use_container_width=True,
)

average_diff = yield_diff_df['diff'].mean()

paint_price_per_liter_df = get_paint_price_per_liter(paint_per_date_df)

average_paint_price_per_liter = paint_price_per_liter_df['price_per_liter_usd'].mean()

economic_yield_difference = average_paint_price_per_liter * average_diff

col1, col2 = st.columns(2)

with col1:
    st.metric('Diferencia promedio', '{:.2f} L/m²'.format(average_diff))
with col2:
    st.metric('Diferencia de Rendimiento Economico (USD)', '{:.2f} $/m²'.format(economic_yield_difference))

st.markdown('''
En promedio, la línea de producción 1 presenta un rendimiento menor al de la línea 2. Calculado para todo el periodo de
datos proporcionado por Ternium, tienen una diferencia promedio de 17.98 L/m².

Para profundizar sobre este fenómeno, se decidio analizar esta diferencia por pintura en cada línea de producción. 
Para esto se recopilaron las pinturas que están en ambas líneas de producción, con lo que podemos calcular las 
diferencias de rendimientos por pintura. La siguiente gráfica muestra los valores por pintura:
''')

both_lines_df = remove_single_production_line_paints(paint_per_date_df)
paint_names_by_usage = get_paint_names_by_usage(both_lines_df)

selected_paint = st.selectbox('Pintura', paint_names_by_usage, help='Las pinturas más comunes se muestran primero')

per_paint_chart = alt.Chart(
    paint_per_date_df[paint_per_date_df['paint_name'] == selected_paint],
    title='Rendimiento promedio por línea de producción por mes para {}'.format(selected_paint)).mark_line(
    point=True).encode(
    x=alt.X('date', timeUnit=period, title='Fecha'),
    y=alt.Y('real_yield', aggregate='mean', title='Rendimiento (L/m²)'),
    color=alt.Color('production_line', title='Línea de producción'))

st.altair_chart(
    per_paint_chart,
    use_container_width=True,
)

per_paint_yield_diff_df = get_yield_diff_df_for_paint(paint_per_date_df, selected_paint)

per_paint_average_diff = per_paint_yield_diff_df['diff'].mean()

selected_paint_price_per_liter = paint_price_per_liter_df[paint_price_per_liter_df['paint_name'] == selected_paint]['price_per_liter_usd'].item()

economic_yield_difference_per_paint = selected_paint_price_per_liter * per_paint_average_diff


col1, col2 = st.columns(2)

with col1:
    st.metric('Diferencia promedio', '{:.2f} L/m²'.format(per_paint_average_diff),
              delta='{:.2f} L/m²'.format(per_paint_average_diff - average_diff), delta_color='inverse')

with col2:
    st.metric('Diferencia de Rendimiento Economico (USD)', '{:.2f} $/m²'.format(economic_yield_difference_per_paint), delta='{:.2f} $/m²'.format(economic_yield_difference_per_paint - economic_yield_difference), delta_color='inverse')

st.markdown('''
A continuación se muestra una tabla con todas las diferencias de rendimiento para todas las pinturas que estén en ambas
líneas de producción.
''')

paint_yield_diffs_df = pd.DataFrame(map(lambda paint: {'Pintura': paint,
                                                       'Diferencia promedio':
                                                           get_yield_diff_df_for_paint(paint_per_date_df, paint)[
                                                               'diff'].mean()},
                                        paint_names_by_usage)).sort_values(by='Diferencia promedio', ascending=False)

st.dataframe(paint_yield_diffs_df, use_container_width=True, hide_index=True)

st.markdown('''
Al analizar detalladamente cada una de las pinturas, encontramos que para todas las pinturas, la diferencia promedio
es menor que el valor global. Esto nos indica que parte de la diferencia de rendimientos entre las líneas de producción
se debe a pinturas que solo se usan en una de las líneas de producción, no en ambas. Por lo tanto, para tener mayor 
claridad se eliminaron todas las pinturas que no estén en ambas líneas de producción. La siguientes gráficas muestra
los rendimientos promedio una vez eliminadas estas pinturas:
''')

filtered_ppd_df = paint_per_date_df[paint_per_date_df['paint_name'].isin(paint_names_by_usage)]

yield_chart = alt.Chart(filtered_ppd_df,
                        title='Rendimiento promedio por línea de producción por mes (filtrada)').mark_line(
    point=True).encode(
    x=alt.X('date', timeUnit=period, title='Fecha'),
    y=alt.Y('real_yield', aggregate='mean', title='Rendimiento (L/m²)'),
    color=alt.Color('production_line', title='Línea de producción'))

st.altair_chart(
    yield_chart,
    use_container_width=True,
)

filtered_yield_diff_df = get_yield_diff_df(filtered_ppd_df)

filtered_diff_chart = alt.Chart(filtered_yield_diff_df,
                                title='Diferencia entre las líneas de producción (línea 2 menos línea 1, filtrada)').mark_line(
    point=True).encode(
    x=alt.X('date', timeUnit=period, title='Fecha'),
    y=alt.Y('diff', aggregate='mean', title='Diferencia (L/m²)'),
)

st.altair_chart(
    filtered_diff_chart,
    use_container_width=True,
)

fil_average_diff = filtered_yield_diff_df['diff'].mean()


paint_price_per_liter_filtered_df = get_paint_price_per_liter(filtered_ppd_df)

average_paint_price_per_liter = paint_price_per_liter_df['price_per_liter_usd'].mean()

economic_yield_difference_filtered = average_paint_price_per_liter * fil_average_diff


col1, col2 = st.columns(2)

with col1:
    st.metric('Diferencia promedio', '{:.2f} L/m²'.format(fil_average_diff),
              delta='{:.2f} L/m²'.format(fil_average_diff - average_diff), delta_color='inverse')

with col2:
    st.metric('Diferencia de Rendimiento Economico (USD)', '{:.2f} $/m²'.format(economic_yield_difference_filtered), delta='{:.2f} $/m²'.format(economic_yield_difference_per_paint - economic_yield_difference_filtered), delta_color='inverse')

st.markdown('''
El rendimiento promedio final es menor que el valor global, pero aun así existe una diferencia significativa entre ambas
líneas de producción. En promedio, las pinturas que se encuentran en ambas líneas de producción tienden a tener un
rendimiento menor en la línea de producción 1 que en la línea de producción 2.
''')
