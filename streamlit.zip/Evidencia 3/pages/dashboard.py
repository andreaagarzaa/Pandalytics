import streamlit as st
from layout.sidebar import add_sidebar
import pandas as pd
import altair as alt

from shared import get_paint_per_date, convert_period_opt, get_production_lines

st.set_page_config(layout="wide")

add_sidebar(st)


@st.cache_data
def filter_df_date(df, limits):
    filtered_df = df

    if len(limits) > 1:
        filtered_df = filtered_df[pd.to_datetime(limits[1]) > filtered_df['date']]
    filtered_df = filtered_df[pd.to_datetime(limits[0]) < filtered_df['date']]

    return filtered_df


@st.cache_data
def get_paint_day_counts(df):
    result = df.groupby('paint_name').count()['real_yield']
    result.name = 'count'

    return result.to_frame().reset_index()


def to_human(key):
    return {
        'total_liters_used': 'Litros usados (L)',
        'real_yield': 'Rendimiento (L/m²)',
        'm2': 'Metros cuadrados (m²)',
        'input_weight_kg': 'Peso de entrada (kg)',
    }[key]


paint_per_date_df = get_paint_per_date()

st.title('Dashboard')

do_per_line = st.toggle('Por línea de producción')

col1, col2 = st.columns(2)

with col1:
    period = st.radio('Tamaño de periodo', options=['yearmonth', 'yearweek', 'yearmonthdate'],
                      format_func=convert_period_opt)

with col2:
    limits = st.date_input('Rango de tiempo', [paint_per_date_df['date'].min(), paint_per_date_df['date'].max()],
                           paint_per_date_df['date'].min(), paint_per_date_df['date'].max())

filtered_paint_per_date_df = filter_df_date(paint_per_date_df, limits)

p1_df, p2_df = get_production_lines(filtered_paint_per_date_df)

if do_per_line:
    p1_counts_df = get_paint_day_counts(p1_df).assign(line='line 1')
    p2_counts_df = get_paint_day_counts(p2_df).assign(line='line 2')

    most_used_chart_p1 = alt.Chart(p1_counts_df, title='Pinturas más usadas (línea 1)').transform_window(
        rank='rank(count)',
        sort=[alt.SortField('count', order='descending')]
    ).transform_filter(
        alt.datum.rank <= 10
    ).mark_bar().encode(
        x=alt.X('count', title='Días utilizadas'),
        y=alt.Y('paint_name', sort='-x', title='Pintura'),
    )
    most_used_chart_p2 = alt.Chart(p2_counts_df, title='Pinturas más usadas (línea 2)').transform_window(
        rank='rank(count)',
        sort=[alt.SortField('count', order='descending')]
    ).transform_filter(
        alt.datum.rank <= 10
    ).mark_bar(color='lightblue').encode(
        x=alt.X('count', title='Días utilizadas'),
        y=alt.Y('paint_name', sort='-x', title='Pintura'),
    )
    st.altair_chart(most_used_chart_p1, use_container_width=True)
    st.altair_chart(most_used_chart_p2, use_container_width=True)
else:
    paint_day_counts_df = get_paint_day_counts(filtered_paint_per_date_df)

    most_used_chart = alt.Chart(paint_day_counts_df, title='Pinturas más usadas').transform_window(
        rank='rank(count)',
        sort=[alt.SortField('count', order='descending')]
    ).transform_filter(
        alt.datum.rank <= 10
    ).mark_bar().encode(
        x=alt.X('count', title='Días utilizadas'),
        y=alt.Y('paint_name', sort='-x', title='Pintura'),
    )

    st.altair_chart(most_used_chart, use_container_width=True)

variable_to_graph = st.selectbox('Variable a gráficar', [
    'total_liters_used',
    'real_yield',
    'm2',
    'input_weight_kg',
], format_func=to_human)

X_axis = alt.X('date', timeUnit=period, title='Fecha')
Y_axis = alt.Y(variable_to_graph, aggregate='sum', title=to_human(variable_to_graph))

if do_per_line:
    usage_chart = alt.Chart(filtered_paint_per_date_df,
                            title=f'{to_human(variable_to_graph)} total sobre tiempo, por línea').mark_line().encode(
        x=X_axis,
        y=Y_axis,
        color=alt.Color('production_line')
    )

    st.altair_chart(usage_chart, use_container_width=True)
else:
    usage_chart = alt.Chart(filtered_paint_per_date_df,
                            title=f'{to_human(variable_to_graph)} total sobre tiempo').mark_line().encode(
        x=X_axis,
        y=Y_axis,
    )

    st.altair_chart(usage_chart, use_container_width=True)
