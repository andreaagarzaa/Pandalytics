import streamlit as st
from layout.sidebar import add_sidebar

add_sidebar(st)

st.header('Lineas de Produccion')

st.markdown('''
¿Resumen de lo visto en las líneas e produccion, cuáles fueron los datos más fuertes?, que vimos?
''')

st.header('Áreas de oportunidad')

st.markdown('''
recomendaciones para solucionar el problema
    ''')
