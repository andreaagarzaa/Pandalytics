import streamlit as st
from layout.sidebar import add_sidebar

add_sidebar(st)

# Custom CSS to make the image fill the entire viewport
st.markdown(
    """
    <style>
    .full-page-image {
        height: 100vh;
        background-image: url('logo.png');
        background-size: cover;
        background-repeat: no-repeat;
        background-position: center;
        display: flex;
        justify-content: center;
        align-items: center;
        color: white;
        font-size: 2em;
        text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.7);
    }
    .content {
        padding: 20px;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# Full-page image section
st.markdown(
    """
    <div class="full-page-image">
        <div>
            <h1>Pandalytics</h1>
            <p>Bienvenidos</p>
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)

# Additional content
st.markdown("<div class='content'>", unsafe_allow_html=True)

st.image('logo.png', width=300)

st.header('Problemática')

st.markdown('''
    Puntos principales de la problemática en Ternium:
    1. Desperdicio de pintura: Ternium enfrenta pérdidas significativas debido al uso ineficiente de pintura en el proceso de revestimiento de acero. Esta ineficiencia resulta en una cantidad considerable de pintura que se desperdicia, incrementando los costos operativos y afectando la rentabilidad de la empresa.
    ''')

st.header('Contexto')

st.markdown('''
        El tablero está diseñado para analizar las diferencias en el rendimiento de las líneas de producción de Ternium. Nuestra hipótesis es que una de las líneas de producción tiene un mejor rendimiento que la otra. Esto es algo que intentaremos comprobar y solucionar a lo largo de este tablero, proporcionando insights y recomendaciones basadas en los datos analizados.Al validar esta hipótesis, buscamos identificar las causas subyacentes de las ineficiencias y proponer soluciones que optimicen el uso de pintura, mejoren la gestión del inventario y, en última instancia, aumenten la rentabilidad de Ternium.''')
